package br.com.cefet.sismanutencaospring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SismanutencaospringApplicationTests {

	@Test
	void contextLoads() {
	}

}
