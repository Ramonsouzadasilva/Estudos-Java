package br.com.cefet.sismanutencaospring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SismanutencaospringApplication {

	public static void main(String[] args) {
		SpringApplication.run(SismanutencaospringApplication.class, args);
	}

}
